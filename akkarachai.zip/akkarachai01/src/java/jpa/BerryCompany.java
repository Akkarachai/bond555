/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jpa;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Administrator
 */
@Entity
@Table(name = "berry company")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "BerryCompany.findAll", query = "SELECT b FROM BerryCompany b"),
    @NamedQuery(name = "BerryCompany.findByEmployeeId", query = "SELECT b FROM BerryCompany b WHERE b.employeeId = :employeeId"),
    @NamedQuery(name = "BerryCompany.findByTel", query = "SELECT b FROM BerryCompany b WHERE b.tel = :tel"),
    @NamedQuery(name = "BerryCompany.findByAddress", query = "SELECT b FROM BerryCompany b WHERE b.address = :address")})
public class BerryCompany implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 40)
    @Column(name = "employee_id")
    private String employeeId;
    @Size(max = 40)
    @Column(name = "Tel")
    private String tel;
    @Size(max = 40)
    @Column(name = "address")
    private String address;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "berryCompany")
    private Product product;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "berryCompany")
    private Employee employee;

    public BerryCompany() {
    }

    public BerryCompany(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (employeeId != null ? employeeId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof BerryCompany)) {
            return false;
        }
        BerryCompany other = (BerryCompany) object;
        if ((this.employeeId == null && other.employeeId != null) || (this.employeeId != null && !this.employeeId.equals(other.employeeId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jpa.BerryCompany[ employeeId=" + employeeId + " ]";
    }
    
}
